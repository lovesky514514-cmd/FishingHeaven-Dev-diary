---
description: Safely deploy CSharp_Upload/FH_simple.cs into the Tuanjie project
agent: fishing-heaven
---

应用当前项目中的：

```text
CSharp_Upload/FH_simple.cs
```

到：

```text
Assets/Scripts/FishingHeavenDemo.cs
```

严格执行你的版本守门员规则。

必须：

1. 只读检查源文件。
2. 计算源 SHA256。
3. 运行 `FH_Agent/scripts/apply-fh-simple.ps1` 完成备份与原样复制。
4. 读取脚本输出。
5. 确认 SOURCE_SHA256 与 DEST_SHA256 完全一致。
6. 检查重复主类和旧 V1 入口。
7. 不修改任何 C#。
8. 如果编译或项目检查发现错误，只报告。

最终输出：

```text
SOURCE:
DEST:
SOURCE_SHA256:
DEST_SHA256:
HASH_MATCH:
BACKUP:
DUPLICATE_CLASS:
OLD_V1_ACTIVE:
STATUS:
```
