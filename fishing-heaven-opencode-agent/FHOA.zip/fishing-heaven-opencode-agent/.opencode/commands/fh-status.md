---
description: Show a quick read-only Fishing Heaven agent status
agent: fishing-heaven
---

快速只读状态检查。

不要部署，不要编译，不要写入。

输出：

```text
FH_SIMPLE_EXISTS:
DEPLOYED_SCRIPT_EXISTS:
SOURCE_SHA256:
DEST_SHA256:
HASH_MATCH:
MAIN_SCENE_EXISTS:
DUPLICATE_CLASS:
OLD_V1_ACTIVE:
```
