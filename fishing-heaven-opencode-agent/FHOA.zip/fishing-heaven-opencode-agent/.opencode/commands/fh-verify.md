---
description: Verify the current Fishing Heaven project without changing C#
agent: fishing-heaven
---

只读验证当前项目。

检查：

- `CSharp_Upload/FH_simple.cs` 是否存在
- `Assets/Scripts/FishingHeavenDemo.cs` 是否存在
- 两者 SHA256
- 是否存在重复 `FishingHeavenDemo` 类
- 是否存在旧 `FishingHeavenGame.cs`
- 是否存在旧 `FishingHeavenBootstrap.cs`
- 是否存在 `Assets/Scenes/Main.unity`
- 是否有明显旧 V1 字符串
- 当前代码中的版本修改标记

禁止修改任何 C#。

输出简洁状态报告。
